#!/usr/bin/env bash
set -euo pipefail

if [[ ! -d .git ]]; then
  echo "Erreur : lance cette commande depuis la racine du dépôt FightIQ."
  exit 1
fi

if [[ "$(git branch --show-current)" != "main" ]]; then
  echo "Erreur : place-toi sur la branche main avant le nettoyage."
  exit 1
fi

remove_paths=(
  "FightIQ_clean_v6.zip"
  "START_HERE.txt"
  "scripts/audit_fighters_v1.py"
  "scripts/audit_remaining_fighter_gaps.py"
  "scripts/complete_fighter_profiles_cito_v2.py"
  "scripts/consolidate_fighter_identities_v5_6.py"
  "scripts/enrich_fighters_cito_v5_1_update_only.py"
  "scripts/import_fighters.py"
  ".github/workflows/complete-fighter-profiles-cito-v2.yml"
  ".github/workflows/consolidate-fighter-identities-v5-6.yml"
  ".github/workflows/install-fightiq-package.yml"
  "data/cito_identity_resolution_v5_6.json"
  "data/cito_identity_overrides.json"
)

keep_paths=(
  ".github/workflows/update-fighters.yml"
  ".github/workflows/update-rankings.yml"
  ".gitignore"
  "FIGHTIQ_ADMIN_IDENTITY_REVIEW.md"
  "FIGHTIQ_CHANGELOG.md"
  "FIGHTIQ_DATA_ARCHITECTURE.md"
  "FIGHTIQ_PROJECT_CONTEXT.md"
  "INSTALLATION.md"
  "README.md"
  "data/fighter_identity_registry.json"
  "reports/README.md"
  "requirements.txt"
  "scripts/enrich_rankings_cito.py"
  "scripts/sync_fighters.py"
  "supabase/migrations/202608170001_fighter_identity_admin_review.sql"
  "supabase/migrations/202608180001_merge_fighter_identities.sql"
  "tests/test_enrich_rankings_cito.py"
  "tests/test_sync_fighters.py"
)

git rm --ignore-unmatch -- "${remove_paths[@]}"
git add -- "${keep_paths[@]}"

python -m py_compile scripts/sync_fighters.py scripts/enrich_rankings_cito.py
python -m json.tool data/fighter_identity_registry.json >/dev/null
python -m unittest discover -s tests -v

mapfile -t intended_changes < <(
  git diff --cached --name-only -- "${keep_paths[@]}" "${remove_paths[@]}"
)

if (( ${#intended_changes[@]} == 0 )); then
  echo "Aucune modification FightIQ à enregistrer."
else
  git commit -m "Clean canonical fighter pipeline" -- "${intended_changes[@]}"
  git push origin main
fi

rm -f -- FightIQ_clean_v6.zip "$0"

echo
echo "Nettoyage terminé sur main."
echo "Étape suivante : appliquer la migration Supabase V5.8 puis lancer le workflow Fighters en dry_run=false."
